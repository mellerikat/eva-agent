{{/*
Expand the name of the chart.
*/}}
{{- define "eva-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "eva-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "eva-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "eva-agent.labels" -}}
helm.sh/chart: {{ include "eva-agent.chart" . }}
{{ include "eva-agent.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Hard-coded PVC claim name for the model cache.
*/}}
{{- define "eva-agent.modelCacheClaimName" -}}
{{- if .Values.persistence.claimName -}}
{{- .Values.persistence.claimName -}}
{{- else -}}
eva-agent-models
{{- end -}}
{{- end }}

{{/*
ServiceAccount name for the ECR refresh CronJob.
*/}}
{{- define "eva-agent.ecrRefreshServiceAccountName" -}}
{{- if .Values.ecrRefresh.serviceAccount.name }}
{{- .Values.ecrRefresh.serviceAccount.name }}
{{- else if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- printf "%s-ecr-refresh" (include "eva-agent.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Role name for the ECR refresh CronJob.
*/}}
{{- define "eva-agent.ecrRefreshRoleName" -}}
{{- printf "%s-ecr-refresh" (include "eva-agent.fullname" .) }}
{{- end }}
