# eva-agent-vllm Helm Chart

이 차트는 upstream `vllm-stack 0.1.10`을 기준으로 유지하는 EVA용 포크입니다.

## 기준 버전

- upstream chart: `vllm-project/production-stack` `vllm-stack 0.1.10`
- downstream chart: `eva-agent-vllm 0.1.10`
- 운영 원칙: upstream 기능은 최대한 그대로 유지하고, EVA 운영에 필요한 로컬 변경만 최소화해서 유지

## Upstream 문서

전체 values 설명과 기본 사용법은 upstream 문서를 기준으로 확인합니다.

- upstream chart README:
  <https://github.com/vllm-project/production-stack/blob/vllm-stack-0.1.10/helm/README.md>
- upstream values.yaml:
  <https://github.com/vllm-project/production-stack/blob/vllm-stack-0.1.10/helm/values.yaml>

## 기본 사용 예시

설치:

```bash
helm install eva-agent-vllm ./deploy/helm/charts/eva-agent-vllm -f my-values.yaml
```

업그레이드:

```bash
helm upgrade eva-agent-vllm ./deploy/helm/charts/eva-agent-vllm -f my-values.yaml
```

삭제:

```bash
helm uninstall eva-agent-vllm
```

## 로컬 전용 변경 사항

아래 항목은 upstream `0.1.10`에는 없고, 이 포크에서만 유지하는 동작입니다.

### 1. PVC/PV 보존

Helm uninstall 또는 재배포 시 모델 캐시/스토리지 리소스가 같이 제거되지 않도록 다음 리소스에 `helm.sh/resource-policy: keep`를 유지합니다.

- 모델별 PVC
- shared PV
- shared PVC

관련 템플릿:

- [templates/pvc.yaml](./templates/pvc.yaml)
- [templates/shared-storage.yaml](./templates/shared-storage.yaml)

### 2. Shared PVC 정적/동적 모드

`sharedPvcStorage.mode`를 추가로 지원합니다.

- `static`: PV + PVC 생성
- `dynamic`: PVC만 생성

upstream은 shared storage를 정의하면 PV/PVC를 함께 생성하는 방향인데, 이 포크는 동적 프로비저닝 환경에서 PVC만 생성하는 구성도 허용합니다.

관련 파일:

- [templates/shared-storage.yaml](./templates/shared-storage.yaml)
- [values.yaml](./values.yaml)

### 3. Shared PVC 사용 시 `HF_HOME` 경로 변경

`sharedPvcStorage`가 설정되면 serving engine 컨테이너의 `HF_HOME`을 `/data/shared-pvc-storage`로 사용합니다.

- shared PVC 사용 시: `/data/shared-pvc-storage`
- 모델별 PVC 사용 시: `/data`
- 둘 다 없으면: `/tmp`

관련 파일:

- [templates/deployment-vllm-multi.yaml](./templates/deployment-vllm-multi.yaml)

### 4. Router probe timeout 및 완화된 기본값

router probe에 `timeoutSeconds`를 직접 렌더링하고, upstream 기본값보다 보수적인 기본값을 유지합니다.

현재 로컬 기본값:

- `livenessProbe`: `initialDelaySeconds=60`, `periodSeconds=10`, `timeoutSeconds=2`, `failureThreshold=6`
- `startupProbe`: `initialDelaySeconds=10`, `periodSeconds=5`, `timeoutSeconds=2`, `failureThreshold=24`
- `readinessProbe`: `initialDelaySeconds=0`, `periodSeconds=5`, `timeoutSeconds=2`, `failureThreshold=6`

관련 파일:

- [templates/deployment-router.yaml](./templates/deployment-router.yaml)
- [values.yaml](./values.yaml)

## 운영 메모

- 새 기능이나 옵션을 추가할 때는 먼저 upstream `vllm-stack`에 이미 반영되었는지 확인합니다.
- 이 포크에만 필요한 동작이면 이 README의 `로컬 전용 변경 사항`에 함께 기록합니다.
- 상세 옵션 문서는 이 README에 복제하지 않고 upstream 문서를 기준으로 유지합니다.
