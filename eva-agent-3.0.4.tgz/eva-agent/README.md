# eva-agent Helm Chart

## vLLM Engine Health RBAC

`eva-agent`는 application 내부에서 Kubernetes API를 호출하여 runtime에 vLLM
engine pod를 discovery할 수 있음
runtime image에는 `kubectl`, kubeconfig file, host machine Kubernetes config가
필요하지 않음

Kubernetes는 token automounting이 disable되어 있지 않으면 configured
ServiceAccount token을 pod에 자동 mount함
chart의 `vllmEngineHealth.rbac.create` setting은 해당 ServiceAccount에 권한만
부여하며 token을 생성하거나 inject하지 않음

health checker가 읽는 resource는 아래와 같음

- core API group의 `pods`, vLLM engine pod IP 조회 용도

router 또는 Service ClusterIP 대신 pod IP를 직접 사용하는 이유는 load balancing
endpoint가 request를 처리한 replica를 숨기기 때문
runtime Pod list discovery는 Helm 또는 initContainer의 startup snapshot에
의존하지 않고 pod restart, scale change, rolling update를 따라갈 수 있음

static mode는 local Docker 또는 single-container smoke check를 위해 application
code에 유지되는 mode
